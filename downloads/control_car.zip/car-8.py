from zmqRemoteApi_IPv6 import RemoteAPIClient
import time
import math
import keyboard
 
# 利用 zmqRemoteAPI 以 23000 對場景伺服器進行連線
client = RemoteAPIClient('2001:288:6004:17:2023:cdb:1:1', 23000)
print('Program started')
sim = client.getObject('sim')
# 為最後球員，啟動模擬
sim.startSimulation()
# 加入按鍵狀態, 起始值為 false
key_pressed = False
counter = 0

bubbleRob = sim.getObject('/bubbleRob8')
pos = [-0.5,1,0.2]
ang = [0,0,-3.14]
    
def setBubbleRobVelocity(leftWheelVelocity, rightWheelVelocity):
    leftMotor = sim.getObject('/leftMotor8')
    rightMotor = sim.getObject('/rightMotor8')
    sim.setJointTargetVelocity(leftMotor, leftWheelVelocity)
    sim.setJointTargetVelocity(rightMotor, rightWheelVelocity)

'''
# Example usage 1:
setBubbleRobVelocity(1.0, 1.0)
time.sleep(2)
setBubbleRobVelocity(0.0, 0.0)
'''

while True:
	if keyboard.is_pressed('up'):
		setBubbleRobVelocity(5.0, 5.0)
	elif keyboard.is_pressed('down'):
		setBubbleRobVelocity(-3.0, -3.0)
	elif keyboard.is_pressed('left'):
		setBubbleRobVelocity(-3.0, 3.0)
	elif keyboard.is_pressed('right'):
		setBubbleRobVelocity(3.0, -3.0)
	elif keyboard.is_pressed('q'):
		sim.setObjectPosition(bubbleRob, -1,pos)
		sim.setObjectOrientation(bubbleRob, -1,ang)
	else:
		setBubbleRobVelocity(0.0, 0.0)