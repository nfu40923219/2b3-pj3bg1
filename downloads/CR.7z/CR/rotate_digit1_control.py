from zmqRemoteApi_IPv6 import RemoteAPIClient
import time
import math
import keyboard

client = RemoteAPIClient('localhost', 23000)
sim = client.getObject('sim')
joint1_handle = sim.getObject('/joint1')
sim.startSimulation()
key_pressed = False
counter = 0
target_angle = math.radians(0)

while True:
    if keyboard.is_pressed('i'):
        if not key_pressed:
            print("i 鍵按下!")
            counter = counter + 1
            print(counter)
            target_angle = math.radians(-36)
            current_angle = sim.getJointPosition(joint1_handle)
            print(current_angle)
            new_angle = current_angle + target_angle
            sim.setJointTargetPosition(joint1_handle, new_angle)
            key_pressed = True
    else:
        key_pressed = False
    if keyboard.is_pressed('q'):
        break
        time.sleep(0.01)